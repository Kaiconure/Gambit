local meta = {
    ['WHM'] = true,
    ['BLM'] = true,
    ['RDM'] = true,
    ['PLD'] = true,
    ['DRK'] = true,
    ['SMN'] = true,
    ['BLU'] = true,
    ['SCH'] = true,
    ['GEO'] = true
}

return meta